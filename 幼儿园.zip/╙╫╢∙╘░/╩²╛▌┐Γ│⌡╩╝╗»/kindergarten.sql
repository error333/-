/*==============================================================*/
/* DBMS name:      ORACLE Version 11g                           */
/* Created on:     2020/1/18 23:39:03                           */
/*==============================================================*/


drop table ADMIN_INFO cascade constraints;

drop table ADMIN_LOG_INFO cascade constraints;

drop table BABY_ATTEND_INFO cascade constraints;

drop table BABY_EXAM_INFO cascade constraints;

drop table BABY_INFO cascade constraints;

drop table BABY_MEAL_INFO cascade constraints;

drop table CHAT_INFO cascade constraints;

drop table CLASS_INFO cascade constraints;

drop table COURSE_INFO cascade constraints;

drop table FRONT_LOG_INFO cascade constraints;

drop table HOMEWORK_INFO cascade constraints;

drop table INFORM_INFO cascade constraints;

drop table KEY_INFO cascade constraints;

drop table KINDERGARTEN_INFO cascade constraints;

drop table KINDERGARTEN_REV_INFO cascade constraints;

drop table LIVE_INFO cascade constraints;

drop table MENU_INFO cascade constraints;

drop table NEW_INFO cascade constraints;

drop table NOTICE_INFO cascade constraints;

drop table OPTION_INFO cascade constraints;

drop table PARAM_INFO cascade constraints;

drop table PARENT_BABY_REL cascade constraints;

drop table PARENT_INFO cascade constraints;

drop table PICTURE_BOOK_INFO cascade constraints;

drop table QUESTION_INFO cascade constraints;

drop table ROLE_INFO cascade constraints;

drop table ROLE_MENU_REL cascade constraints;

drop table SAFE_EDU_INFO cascade constraints;

drop table TEACHER_ATTEND_INFO cascade constraints;

drop table TEACHER_INFO cascade constraints;

drop table VIDEO_INFO cascade constraints;

drop sequence SEQ_ADMIN_INFO;

drop sequence SEQ_ADMIN_LOG_INFO;

drop sequence SEQ_BABY_ATTEND_INFO;

drop sequence SEQ_BABY_EXAM_INFO;

drop sequence SEQ_BABY_INFO;

drop sequence SEQ_BABY_MEAL_INFO;

drop sequence SEQ_CHAT_INFO;

drop sequence SEQ_COURSE_INFO;

drop sequence SEQ_FRONT_LOG_INFO;

drop sequence SEQ_HOMEWORK_INFO;

drop sequence SEQ_INFORM_INFO;

drop sequence SEQ_KEY_INFO;

drop sequence SEQ_KINDERGARTEN_INFO;

drop sequence SEQ_KINDERGARTEN_REV_INFO;

drop sequence SEQ_LIVE_INFO;

drop sequence SEQ_MENU_INFO;

drop sequence SEQ_NEW_INFO;

drop sequence SEQ_OPTION_INFO;

drop sequence SEQ_PARAM_INFO;

drop sequence SEQ_PARENT_BABY_REL;

drop sequence SEQ_PARENT_INFO;

drop sequence SEQ_PICTURE_BOOK_INFO;

drop sequence SEQ_QUESTION_INFO;

drop sequence SEQ_ROLE_INFO;

drop sequence SEQ_ROLE_MENU_REL;

drop sequence SEQ_SAFE_EDU_INFO;

drop sequence SEQ_TEACHER_ATTEND_INFO;

drop sequence SEQ_TEACHER_INFO;

drop sequence SEQ_VIDEO_INFO;

create sequence SEQ_ADMIN_INFO
increment by 1
start with 100;

create sequence SEQ_ADMIN_LOG_INFO
increment by 1
start with 100;

create sequence SEQ_BABY_ATTEND_INFO
increment by 1
start with 100;

create sequence SEQ_BABY_EXAM_INFO
increment by 1
start with 100;

create sequence SEQ_BABY_INFO
increment by 1
start with 100;

create sequence SEQ_BABY_MEAL_INFO
increment by 1
start with 100;

create sequence SEQ_CHAT_INFO
increment by 1
start with 100;

create sequence SEQ_COURSE_INFO
increment by 1
start with 100;

create sequence SEQ_FRONT_LOG_INFO
increment by 1
start with 100;

create sequence SEQ_HOMEWORK_INFO
increment by 1
start with 100;

create sequence SEQ_INFORM_INFO
increment by 1
start with 100;

create sequence SEQ_KEY_INFO
increment by 1
start with 100;

create sequence SEQ_KINDERGARTEN_INFO
increment by 1
start with 100;

create sequence SEQ_KINDERGARTEN_REV_INFO
increment by 1
start with 100;

create sequence SEQ_LIVE_INFO
increment by 1
start with 100;

create sequence SEQ_MENU_INFO
increment by 1
start with 100;

create sequence SEQ_NEW_INFO
increment by 1
start with 100;

create sequence SEQ_OPTION_INFO
increment by 1
start with 100;

create sequence SEQ_PARAM_INFO
increment by 1
start with 100;

create sequence SEQ_PARENT_BABY_REL
increment by 1
start with 100;

create sequence SEQ_PARENT_INFO
increment by 1
start with 100;

create sequence SEQ_PICTURE_BOOK_INFO
increment by 1
start with 100;

create sequence SEQ_QUESTION_INFO
increment by 1
start with 100;

create sequence SEQ_ROLE_INFO
increment by 1
start with 100;

create sequence SEQ_ROLE_MENU_REL
increment by 1
start with 100;

create sequence SEQ_SAFE_EDU_INFO
increment by 1
start with 100;

create sequence SEQ_TEACHER_ATTEND_INFO
increment by 1
start with 100;

create sequence SEQ_TEACHER_INFO
increment by 1
start with 100;

create sequence SEQ_VIDEO_INFO
increment by 1
start with 100;

/*==============================================================*/
/* Table: ADMIN_INFO                                            */
/*==============================================================*/
create table ADMIN_INFO 
(
   ADMIN_ID             NUMBER(10)           not null,
   ADMIN_NAME           VARCHAR2(100),
   ADMIN_USERNAME       VARCHAR2(100),
   ADMIN_PSW            VARCHAR2(100),
   constraint PK_ADMIN_INFO primary key (ADMIN_ID)
);

/*==============================================================*/
/* Table: ADMIN_LOG_INFO                                        */
/*==============================================================*/
create table ADMIN_LOG_INFO 
(
   ADMIN_LOG_ID         NUMBER(10)           not null,
   ADMIN_ID             NUMBER(10),
   DO_NAME              NUMBER(3),
   DO_CTIME             DATE,
   KINDERGARTEN_ID      NUMBER(10),
   constraint PK_ADMIN_LOG_INFO primary key (ADMIN_LOG_ID)
);

/*==============================================================*/
/* Table: BABY_ATTEND_INFO                                      */
/*==============================================================*/
create table BABY_ATTEND_INFO 
(
   BABY_ATTEND_ID       NUMBER(10)           not null,
   BABY_COME_TIME       VARCHAR2(100),
   BABY_GO_TIME         VARCHAR2(100),
   BABY_ATTEND_STATE    NUMBER(2),
   BABY_ATTEND_TIME     DATE,
   PARENT_ID            NUMBER(10),
   constraint PK_BABY_ATTEND_INFO primary key (BABY_ATTEND_ID)
);

/*==============================================================*/
/* Table: BABY_EXAM_INFO                                        */
/*==============================================================*/
create table BABY_EXAM_INFO 
(
   BABY_EXAM_ID         NUMBER(10)           not null,
   BABY_EXAM_TIME       DATE,
   BABY_HEIGHT          VARCHAR2(100),
   BABY_WEIGHT          VARCHAR2(100),
   BABY_VISION          VARCHAR2(100),
   BABY_TEMPERATURE     VARCHAR2(100),
   BABY_SKIN            NUMBER(1),
   BABY_HEALTH_CONDITION NUMBER(2),
   constraint PK_BABY_EXAM_INFO primary key (BABY_EXAM_ID)
);

/*==============================================================*/
/* Table: BABY_INFO                                             */
/*==============================================================*/
create table BABY_INFO 
(
   BABY_ID              NUMBER(10)           not null,
   BABY_NAME            VARCHAR2(100),
   BABY_SEX             NUMBER(1),
   EXAM_ID              NUMBER(10),
   ATTEND_ID            NUMBER(10),
   CLASS_ID             NUMBER(10),
   KINDERGARTEN_ID      NUMBER(10),
   constraint PK_BABY_INFO primary key (BABY_ID)
);

/*==============================================================*/
/* Table: BABY_MEAL_INFO                                        */
/*==============================================================*/
create table BABY_MEAL_INFO 
(
   BABY_MEAL_ID         NUMBER(10)           not null,
   MEAL_STATE           NUMBER(1),
   BABY_MEAL_TIME       DATE,
   SPECIFIC_FOOD        VARCHAR2(200),
   constraint PK_BABY_MEAL_INFO primary key (BABY_MEAL_ID)
);

/*==============================================================*/
/* Table: CHAT_INFO                                             */
/*==============================================================*/
create table CHAT_INFO 
(
   CHAT_ID              NUMBER(10)           not null,
   CHAT_TIME            DATE,
   TEACHER_ID           NUMBER(10),
   PARENT_ID            NUMBER(10),
   CHAT_CONTENT         VARCHAR2(200),
   constraint PK_CHAT_INFO primary key (CHAT_ID)
);

/*==============================================================*/
/* Table: CLASS_INFO                                            */
/*==============================================================*/
create table CLASS_INFO 
(
   CLASS_ID             NUMBER(10)           not null,
   CLASS_NAME           VARCHAR2(100),
   KINDERGARTEN_ID      NUMBER(10),
   constraint PK_CLASS_INFO primary key (CLASS_ID)
);

/*==============================================================*/
/* Table: COURSE_INFO                                           */
/*==============================================================*/
create table COURSE_INFO 
(
   COURSE_ID            NUMBER(10)           not null,
   COURSE_NAME          VARCHAR2(100),
   CLASS_ID             NUMBER(10),
   COURSE_TIME          DATE,
   LESSON_NUM           NUMBER(1),
   KINDERGARTEN_ID      NUMBER(10),
   constraint PK_COURSE_INFO primary key (COURSE_ID)
);

/*==============================================================*/
/* Table: FRONT_LOG_INFO                                        */
/*==============================================================*/
create table FRONT_LOG_INFO 
(
   FRONT_LOG_ID         NUMBER(10)           not null,
   TEACHER_ID           NUMBER(10),
   DO_NAME              NUMBER(3),
   DO_CTIME             DATE,
   KINDERGARTEN_ID      NUMBER(10),
   constraint PK_FRONT_LOG_INFO primary key (FRONT_LOG_ID)
);

/*==============================================================*/
/* Table: HOMEWORK_INFO                                         */
/*==============================================================*/
create table HOMEWORK_INFO 
(
   HOMEWORK_ID          NUMBER(10)           not null,
   HOMEWORK_NAME        VARCHAR2(100),
   RELEASE_TIME         DATE,
   COMPLETION_STATE     NUMBER(1),
   HOMEWORK_PATH        VARCHAR2(200),
   HOMEWORK_EVALUATION  NUMBER(1),
   BABY_ID              NUMBER(10),
   HOMEWORK_STATE       NUMBER(1),
   constraint PK_HOMEWORK_INFO primary key (HOMEWORK_ID)
);

/*==============================================================*/
/* Table: INFORM_INFO                                           */
/*==============================================================*/
create table INFORM_INFO 
(
   INFORM_ID            NUMBER(10)           not null,
   INFORM_CONTENT       VARCHAR2(500),
   KINDERGARTEN_ID      NUMBER(10),
   INFORM_STATE         NUMBER(1),
   constraint PK_INFORM_INFO primary key (INFORM_ID)
);

/*==============================================================*/
/* Table: KEY_INFO                                              */
/*==============================================================*/
create table KEY_INFO 
(
   KEY_ID               NUMBER(10)           not null,
   OPTION_ID            NUMBER(10),
   QUESTON_ID           NUMBER(10),
   constraint PK_KEY_INFO primary key (KEY_ID)
);

/*==============================================================*/
/* Table: KINDERGARTEN_INFO                                     */
/*==============================================================*/
create table KINDERGARTEN_INFO 
(
   KINDERGARTEN_ID      NUMBER(10)           not null,
   KINDERGARTEN_NAME    VARCHAR2(100),
   LEADER_ID            NUMBER(10),
   LEADER_IDENTITY_CARD VARCHAR2(100),
   KINDERGARTEN_ADDRESS VARCHAR2(200),
   KINDERGARTEN_PHONE   VARCHAR2(100),
   RUN_SCHOOL_LICENSE   VARCHAR2(100),
   HEALTH_LICENSE       VARCHAR2(100),
   FIREFIGHTING_LICENSE VARCHAR2(100),
   ORGANIZATION_LICENSE VARCHAR2(100),
   TAX_LICENSE          VARCHAR2(100),
   constraint PK_KINDERGARTEN_INFO primary key (KINDERGARTEN_ID)
);

/*==============================================================*/
/* Table: KINDERGARTEN_REV_INFO                                 */
/*==============================================================*/
create table KINDERGARTEN_REV_INFO 
(
   KINDERGARTEN_REV_ID  NUMBER(10)           not null,
   KINDERGARTEN_ID      NUMBER(10),
   LEADER_ID            NUMBER(10),
   ADMIN_ID             NUMBER(10),
   APPLICATION_TIME     DATE,
   REVIEW_TIME          DATE,
   REVIEW_STATE         NUMBER(1),
   constraint PK_KINDERGARTEN_REV_INFO primary key (KINDERGARTEN_REV_ID)
);

/*==============================================================*/
/* Table: LIVE_INFO                                             */
/*==============================================================*/
create table LIVE_INFO 
(
   LIVE_ID              NUMBER(10)           not null,
   MONITOR_IMAGE        VARCHAR2(200),
   MONITOR_LOCATION     VARCHAR2(100),
   constraint PK_LIVE_INFO primary key (LIVE_ID)
);

/*==============================================================*/
/* Table: MENU_INFO                                             */
/*==============================================================*/
create table MENU_INFO 
(
   MENU_ID              NUMBER(10)           not null,
   MENU_NAME            VARCHAR2(100),
   MENU_URL             VARCHAR2(200),
   PMENU_ID             NUMBER(10),
   MENU_ICON            VARCHAR2(100),
   MENU_CTIME           DATE,
   MENU_STATE           NUMBER(1),
   constraint PK_MENU_INFO primary key (MENU_ID)
);

/*==============================================================*/
/* Table: NEW_INFO                                              */
/*==============================================================*/
create table NEW_INFO 
(
   NEW_ID               NUMBER(10)           not null,
   NEW_NAME             VARCHAR2(100),
   NEW_CONTENT          VARCHAR2(200),
   NEW_CTIME            DATE,
   KINDERGARTEN_ID      NUMBER(10),
   constraint PK_NEW_INFO primary key (NEW_ID)
);

/*==============================================================*/
/* Table: NOTICE_INFO                                           */
/*==============================================================*/
create table NOTICE_INFO 
(
   NOTICE_ID            NUMBER(10)           not null,
   NOTICE_TITLE         VARCHAR2(100),
   NOTICE_CONTENT       VARCHAR2(500),
   NOTICE_TIME          DATE,
   KINDERGARTEN_ID      NUMBER(10),
   constraint PK_NOTICE_INFO primary key (NOTICE_ID)
);

/*==============================================================*/
/* Table: OPTION_INFO                                           */
/*==============================================================*/
create table OPTION_INFO 
(
   OPTION_ID            NUMBER(10)           not null,
   OPTION_NAME          VARCHAR2(100),
   QUESTION_ID          NUMBER(10),
   constraint PK_OPTION_INFO primary key (OPTION_ID)
);

/*==============================================================*/
/* Table: PARAM_INFO                                            */
/*==============================================================*/
create table PARAM_INFO 
(
   PARAM_ID             NUMBER(10)           not null,
   CODE                 VARCHAR2(100),
   CODE_NAME            VARCHAR2(100),
   KEY_NAME             VARCHAR2(100),
   KEY_VALUE            NUMBER(10),
   constraint PK_PARAM_INFO primary key (PARAM_ID)
);

/*==============================================================*/
/* Table: PARENT_BABY_REL                                       */
/*==============================================================*/
create table PARENT_BABY_REL 
(
   PARENT_BABY_REL_ID   NUMBER(10)           not null,
   PARENT_ID            NUMBER(10),
   BABY_ID              NUMBER(10),
   constraint PK_PARENT_BABY_REL primary key (PARENT_BABY_REL_ID)
);

/*==============================================================*/
/* Table: PARENT_INFO                                           */
/*==============================================================*/
create table PARENT_INFO 
(
   PARENT_ID            NUMBER(10)           not null,
   PARENT_USERNAME      VARCHAR2(100),
   PARENT_PSW           VARCHAR2(100),
   PARENT_NAME          VARCHAR2(100),
   RELATION             VARCHAR2(100),
   BIRTH_TIME           VARCHAR2(100),
   PARENT_PHONE         VARCHAR2(100),
   PARENT_ADDRESS       VARCHAR2(100),
   PARENT_PROFESSION    VARCHAR2(100),
   constraint PK_PARENT_INFO primary key (PARENT_ID)
);

/*==============================================================*/
/* Table: PICTURE_BOOK_INFO                                     */
/*==============================================================*/
create table PICTURE_BOOK_INFO 
(
   PICTURE_BOOK_ID      NUMBER(10)           not null,
   PICTURE_BOOK_NAME    VARCHAR2(100),
   PICTURE_BOOK_PATH    VARCHAR2(200),
   UPLOAD_TIME          DATE,
   KINDERGARTEN_ID      NUMBER(10),
   constraint PK_PICTURE_BOOK_INFO primary key (PICTURE_BOOK_ID)
);

/*==============================================================*/
/* Table: QUESTION_INFO                                         */
/*==============================================================*/
create table QUESTION_INFO 
(
   QUESTION_ID          NUMBER(10)           not null,
   VIDEO_ID             NUMBER(10),
   QUESTION_CONTENT     VARCHAR2(200),
   QUESTION_SCORE       NUMBER(10),
   constraint PK_QUESTION_INFO primary key (QUESTION_ID)
);

/*==============================================================*/
/* Table: ROLE_INFO                                             */
/*==============================================================*/
create table ROLE_INFO 
(
   ROLE_ID              NUMBER(10)           not null,
   ROLE_NAME            VARCHAR(100),
   ROLE_CTIME           DATE,
   ROLE_STATE           NUMBER(1),
   constraint PK_ROLE_INFO primary key (ROLE_ID)
);

/*==============================================================*/
/* Table: ROLE_MENU_REL                                         */
/*==============================================================*/
create table ROLE_MENU_REL 
(
   RM_ID                NUMBER(10)           not null,
   ROLE_ID              NUMBER(10),
   MENU_ID              NUMBER(10),
   constraint PK_ROLE_MENU_REL primary key (RM_ID)
);

/*==============================================================*/
/* Table: SAFE_EDU_INFO                                         */
/*==============================================================*/
create table SAFE_EDU_INFO 
(
   SAFE_EDU_ID          NUMBER(10)           not null,
   RELEASE_TIME         DATE,
   SCORE                NUMBER(10),
   COMPLETION_STATE     NUMBER(1),
   VIDEO_ID             NUMBER(10),
   KINDERGARTEN_ID      NUMBER(10),
   constraint PK_SAFE_EDU_INFO primary key (SAFE_EDU_ID)
);

/*==============================================================*/
/* Table: TEACHER_ATTEND_INFO                                   */
/*==============================================================*/
create table TEACHER_ATTEND_INFO 
(
   TEACHER_ATTEND_ID    NUMBER(10)           not null,
   MORNING_COME_TIME    VARCHAR2(100),
   MORNING_GO_TIME      VARCHAR2(100),
   MORNING_STATE        NUMBER(1),
   AFTERNOOM_COME_TIME  VARCHAR2(100),
   AFTERNOOM_GO_TIME    VARCHAR2(100),
   AFTERNOOM_STATE      NUMBER(1),
   TEACHER_ATTEND_STATE NUMBER(1),
   TEACHER_ATTEND_TIME  DATE,
   constraint PK_TEACHER_ATTEND_INFO primary key (TEACHER_ATTEND_ID)
);

/*==============================================================*/
/* Table: TEACHER_INFO                                          */
/*==============================================================*/
create table TEACHER_INFO 
(
   TEACHER_ID           NUMBER(10)           not null,
   TEACHER_NAME         VARCHAR2(100),
   ROLE_ID              NUMBER(10),
   CLASS_ID             NUMBER(10),
   KINDERGARTEN_ID      NUMBER(10),
   TEACHER_CTIME        DATE,
   constraint PK_TEACHER_INFO primary key (TEACHER_ID)
);

/*==============================================================*/
/* Table: VIDEO_INFO                                            */
/*==============================================================*/
create table VIDEO_INFO 
(
   VIDEO_ID             NUMBER(10)           not null,
   VIDEO_NO             VARCHAR2(100),
   VIDEO_NAME           VARCHAR2(100),
   FILE_NAME            VARCHAR2(100),
   FILE_PATH            VARCHAR2(200),
   UPLOAD_TIME          DATE,
   constraint PK_VIDEO_INFO primary key (VIDEO_ID)
);

