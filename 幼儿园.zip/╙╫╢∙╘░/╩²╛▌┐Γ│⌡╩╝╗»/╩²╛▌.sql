
insert into ADMIN_INFO values(seq_ADMIN_INFO.nextval,'����','123','123');
commit;

